.onLoad <-
function(libname, pkgname)
{
invisible(stats::runif(1))
}
